/*!
 * Documenter 2.0
 * http://rxa.li/documenter
 *
 * Copyright 2011, Xaver Birsak
 * http://revaxarts.com
 *
 */
 
jQuery(document).ready(function() {
	"use strict";
	// ACCORDION
	jQuery(".doc_fn_accordion").avalon_td_accordion({
		showIcon: false, //boolean	
		animation: true, //boolean
		closeAble: true, //boolean
        slideSpeed: 200 //integer, miliseconds
	});
	
});